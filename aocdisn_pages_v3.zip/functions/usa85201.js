export async function onRequest(context) {
  const url = new URL(context.request.url);

  return fetch(
    "http://156.229.160.252:80" + url.pathname + url.search,
    {
      method: context.request.method,
      headers: context.request.headers,
      body: context.request.body
    }
  );
}
